from aiogram.types import BotCommand

private: list = [
    BotCommand(command='start', description='Главное меню'),
]
 